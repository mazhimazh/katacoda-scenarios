插件使用说明
- 下载指定插件
- 将插件的jar包放在XPocket工程目录下的plugins目录下
- 重新启动XPocket

自定义插件请参考：http://xpocket.perfma.com/docs/developer/#%E6%8F%92%E4%BB%B6%E5%BC%80%E5%8F%91