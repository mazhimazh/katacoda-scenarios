#!/bin/sh
cd `pwd`
# bootstap class
MAIN_CLASS="demo.simulators.boot.ThreadSimulatorMain"
echo $MAIN_CLASS

STR=`ps aux|grep ${MAIN_CLASS} | grep -v grep | awk -F ' ' '{print $2}'`
if [ ! -z "$STR" ]; then
    kill -9 $STR > /dev/null 2>&1
    echo "Stopped process ${MAIN_CLASS} (${STR}) successfully."
    sleep 3
fi

APP_HOME=`pwd`

DIR_LOG=${APP_HOME}/logs
if [ ! -e $DIR_LOG ] ; then
    mkdir -p $DIR_LOG
fi

FILE_STDOUT_LOG=$DIR_LOG/stdout.log
FILE_STDERR_LOG=$DIR_LOG/stderr.log

export APP_HOME

JVM_OPTIONS="-Xmx2688M -Xms2688M -Xmn960M -XX:-Inline \
-XX:-TieredCompilation -XX:ReservedCodeCacheSize=256M -XX:InitialCodeCacheSize=256M"

DEBUG_OPTS="-Xdebug -Xrunjdwp:transport=dt_socket,address=8000,server=y,suspend=n"

java $DEBUG_OPTS ${JVM_OPTIONS} -cp "${APP_HOME}/lib/*" \
    -Djava.security.egd=file:/dev/./urandom \
    -Dperfma.config.dir=${APP_HOME}/config \
    -Dapp.path=${APP_HOME} \
    -Dlog.root=${DIR_LOG} \
    ${MAIN_CLASS} > ${FILE_STDOUT_LOG} 2>${FILE_STDERR_LOG} &

if [ $? -ne 0 ]; then
   echo "###### ${MAIN_CLASS} started failed!!!!!"
else
    STR2=`ps aux|grep ${MAIN_CLASS} | grep -v grep | awk -F ' ' '{print $2}'`
    if [ ! -z "$STR2" ]; then
        echo ""
        echo "started process ${MAIN_CLASS} (${STR2}) successfully."
    fi
fi
